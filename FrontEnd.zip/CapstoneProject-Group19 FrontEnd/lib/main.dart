import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/splash_screen.dart';
import 'package:sporthub/pages/login_screen.dart';


void main() {
  runApp(const SportHub());
}
class SportHub extends StatefulWidget {
  const SportHub({super.key});

  @override
  State<SportHub> createState() => _SportHubState();
}

class _SportHubState extends State<SportHub> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:"SportHub",
      home: SplashScreen(),
    );
  }
}
