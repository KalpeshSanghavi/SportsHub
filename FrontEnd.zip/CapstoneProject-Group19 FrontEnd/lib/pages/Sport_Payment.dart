import 'package:flutter/material.dart';
import 'package:sporthub/pages/Confirm_Slot.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';

class Sport_Payment extends StatefulWidget {
  const Sport_Payment({super.key});

  @override
  State<Sport_Payment> createState() => _SportPaymentState();
}

class _SportPaymentState extends State<Sport_Payment> {
  TextEditingController txtpin = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 80),
            Center(
                child: Text(
                  "Make Payment ",
                  style: TextStyle(
                    fontSize: 50,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Sport',
                    color: Color(0xffE77381),
                  ),
                )),
            SizedBox(
              height: 20,
            ),
            Text(
              "Amount : 4000/-",
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w700,
                fontFamily: 'Sport',
                color: Color(0xffE77381),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.all(30.0),
              child: TextField(
                controller: txtpin,
                style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                      BorderSide(color: Color(0xffE77381), width: 2)),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                    BorderSide(color: Color(0xffE77381), width: 2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelText: "Enter UPI Pin",
                  labelStyle: TextStyle(color: Color(0xffE77381), fontSize: 20),
                  hintText: "UPI Pin",
                  hintStyle: TextStyle(color: Color(0xffE77381), fontSize: 15),
                ),
              ),
            ),
            Container(
              height: 50,
              width: 500,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                      backgroundColor: Colors.grey,
                      radius:30,
                      child: CircleAvatar(
                        radius: 23,
                        backgroundImage: AssetImage("assets/img/paytm.png"),
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  CircleAvatar(
                      backgroundColor: Colors.grey,
                      radius:30,
                      child: CircleAvatar(
                        radius: 23,
                        backgroundImage: AssetImage("assets/img/phonepay.png"),
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  CircleAvatar(
                      backgroundColor: Colors.grey,
                      radius:30,
                      child: CircleAvatar(
                        radius: 23,
                        backgroundImage: AssetImage("assets/img/Gpay.png"),
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  CircleAvatar(
                      backgroundColor: Colors.grey,
                      radius:30,
                      child: CircleAvatar(
                        radius: 23,
                        backgroundImage: AssetImage("assets/img/Bhim.png"),
                      )),
                ],
              ),
            ),
            SizedBox(height: 50,),
            InkWell(
              child: Container(
                height: 45,
                width: 150,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                        Color(0xffE7757C),
                        Color(0xffE66C9C),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10)),
                child: Container(
                  margin: EdgeInsets.only(left: 20),
                  child: Text(
                    "Confirm",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => (ConfirmSlotData())));
              },
            )
          ],
        
        ),
      ),
    );
  }
}
