import 'package:flutter/material.dart';
import 'package:sporthub/pages/Profile_Screen.dart';
import 'package:sporthub/pages/home_screen.dart';
import 'package:sporthub/pages/login_screen.dart';
import 'package:sporthub/pages/sport_activity_screen.dart';

import 'menubar_screen.dart';

class Bottom extends StatefulWidget {
  const Bottom({super.key});

  @override
  State<Bottom> createState() => _BottomState();
}

class _BottomState extends State<Bottom> {
  int myCurrentIndex = 0;
  List pages = [
    Welcome(),
    Screen(),
    Menubar(),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: EdgeInsets.only(top: 20),
      decoration: BoxDecoration(color: Colors.red),

      child: BottomNavigationBar(
        backgroundColor: Color(0xffF9E5E5),
        selectedItemColor: Color(0xffE77381),
        unselectedItemColor: Color(0xffE77381),
        currentIndex: myCurrentIndex,
        onTap: (index) {
          setState(() {
            myCurrentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: InkWell(onTap:(){
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Welcome();
              },));
            },child: Icon(Icons.home, size: 35)),
            label: "Home",
          ),
          BottomNavigationBarItem(
              icon: InkWell(onTap:(){
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return Profile();
                },));
              },child: Icon(Icons.account_circle_rounded, size: 35)),
              label: "Profile"),
          BottomNavigationBarItem(
            icon: InkWell(onTap:(){
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Menubar();
              },));
            },child: Icon(Icons.menu, size: 35)),
            label: "Menu",
          ),
        ],
      ),

      // body: pages[myCurrentIndex],
    );
  }
}
