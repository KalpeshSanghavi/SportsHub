import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/tournament.dart';

class Confirm_Tournament extends StatefulWidget {
  const Confirm_Tournament({super.key});

  @override
  State<Confirm_Tournament> createState() => _ConfirmTournamentState();
}

class _ConfirmTournamentState extends State<Confirm_Tournament> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 80,
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                    radius: (30),
                    backgroundColor: Colors.red,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(0),
                      child: Image.asset("assets/img/Correct.png"),
                    )),
                SizedBox(
                  width: 20,
                ),
                Text(
                  "Successfully Payment",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Sport',
                    color: Color(0xffE77381),
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 60,
          ),
          Container(
              height: 100,
              width: 300,
              decoration: BoxDecoration(
                  border: Border.all(width: 2.5, color: Color(0xffE87777)),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Date : ",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Color(0xffE77381)),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "07-10-2023",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Color(0xffE77381)),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Time : ",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Color(0xffE77381)),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "2:00 PM to 6:00 PM",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Color(0xffE77381)),
                      )
                    ],
                  )
                ],
              )),
          SizedBox(
            height: 50,
          ),
          Container(
              height: 100,
              width: 300,
              decoration: BoxDecoration(
                  border: Border.all(width: 2.5, color: Color(0xffE87777)),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(
                      children: [
                        Text(
                          "Name : ",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Color(0xffE77381)),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Kalpesh Sanghvi",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Color(0xffE77381)),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(
                      children: [
                        Text("Contact No : ", style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Color(0xffE77381)),),
                        SizedBox(height: 10,),
                        Text("9824120051", style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Color(0xffE77381)),)
                      ],
                    ),
                  ),
                ],
              )),
          SizedBox(
            height: 30,
          ),
          TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Tournament()),
              );
            },
            child: Text(
              "Back To Home",
              style: TextStyle(
                fontSize: 20,
                color: Color.fromRGBO(231, 115, 129, 1),
                decoration: TextDecoration.underline,
                decorationColor: Color(0xffE77381)
              ),
            ),
          ),
        ],
      ),
    );
  }
}
