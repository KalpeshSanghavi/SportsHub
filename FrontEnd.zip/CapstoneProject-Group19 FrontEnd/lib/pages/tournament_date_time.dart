import 'package:flutter/material.dart';
import 'package:sporthub/pages/ConfirmTournamentData.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';

class Tournament_Date extends StatefulWidget {
  const Tournament_Date({super.key});

  @override
  State<Tournament_Date> createState() => _Tournament_DateState();
}

class _Tournament_DateState extends State<Tournament_Date> {
  TextEditingController date = new TextEditingController();

  Future<void> _selectDate() async {
    DateTime? _picked = await showDatePicker(
        context: context,
        firstDate: DateTime.now(),
        lastDate: DateTime(2050),
        initialDate: DateTime.now());
    if (_picked != null) {
      setState(() {
        date.text = _picked.toString().split(" ")[0];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 40),
            Container(
              height: 55,
              width: 300,
              margin: const EdgeInsets.only(top: 20, right: 30, left: 30),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomLeft,
                    colors: <Color>[
                      Color(0xffE7757C),
                      Color(0xffE66C9C),
                    ],
                  ),
                  borderRadius:
                      BorderRadius.circular(15), // Set border radius here
                ),
                child: TextField(
                  decoration: InputDecoration(
                      //filled: true,
                      //fillColor: LinearGradient(),
                      suffixIcon: Icon(
                        Icons.calendar_month_outlined,
                        color: Colors.white,
                        size: 40,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        //borderRadius: BorderRadius.circular(5),
                      ),
                      hintText: 'Select Date',
                      hintStyle: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                      )),
                  readOnly: true,
                  onTap: () {
                    _selectDate();
                  },
                  controller: date,
                  style: TextStyle(
                      fontSize: 25,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 100),
            Container(
              height: 48,
              width: 320,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  Color(0xffE7757C),
                  Color(0xffE66C9C),
                ],
              )),
              child: Center(
                child: Text(
                  "7:00 AM To 11:00 AM",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
              ),
            ), //1st

            SizedBox(height: 50),
            Container(
              height: 48,
              width: 320,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  Color(0xffE7757C),
                  Color(0xffE66C9C),
                ],
              )),
              child: Center(
                child: Text(
                  "2:00 PM To 6:00 PM",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
              ),
            ), //2nd

            SizedBox(height: 50),
            Container(
              height: 48,
              width: 320,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  Color(0xffE7757C),
                  Color(0xffE66C9C),
                ],
              )),
              child: Center(
                child: Text(
                  "8:00 PM To 12:00 AM",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 80),
            InkWell(
              child: Container(
                height: 45,
                width: 130,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                        Color(0xffE7757C),
                        Color(0xffE66C9C),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10)),
                child: Container(
                  margin: EdgeInsets.only(left: 35),
                  child: Text(
                    "Next",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return ConfirmTournamentData();
                  },
                ));
              },
            )
          ],
        ),
      ),
    );
  }
}
