import 'package:flutter/material.dart';
import 'package:sporthub/pages/ViewTournament.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/tournament_activity_screen.dart';

class Tournament extends StatefulWidget {
  const Tournament({super.key});

  @override
  State<Tournament> createState() => _TournamentState();
}

class _TournamentState extends State<Tournament> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 50,),
            Image(image: AssetImage("assets/img/Tro.png")),
            SizedBox(height: 60),
            InkWell(
              child: Container(
                height: 50,
                width: 333,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomLeft,
                        colors: <Color>[
                          Color(0xffE7757C),
                          Color(0xffE66C9C),
                        ]),
                    borderRadius: BorderRadius.circular(7)),
                child: Center(
                  child: Text(
                    "View Tournament",
                    style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                ),
              ),
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return ViewTournament();
                },));
              },
            ),
            SizedBox(height: 60),
            InkWell(
              child: Container(
                height: 50,
                width: 333,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomLeft,
                        colors: <Color>[
                          Color(0xffE7757C),
                          Color(0xffE66C9C),
                        ]),
                    borderRadius: BorderRadius.circular(7)),
                child: Center(
                  child: Text(
                    "Book Tournament",
                    style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                ),
              ),
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder:(context) => Tournament_Activity()));
              },
            )
          ],
        ),
      ),
    );
  }
}
