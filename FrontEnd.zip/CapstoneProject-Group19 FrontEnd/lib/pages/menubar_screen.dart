import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/PastBooking.dart';
import 'package:sporthub/pages/Profile_Screen.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/home_screen.dart';
import 'package:sporthub/pages/login_screen.dart';
import 'package:sporthub/pages/sport_activity_screen.dart';
import 'package:sporthub/pages/tournament.dart';



class Menubar extends StatelessWidget {
  const Menubar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ), flexibleSpace: Container(decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],)),
      ),),
      body: Padding(
        padding: const EdgeInsets.only(top: 150),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: Center(
                child: SizedBox(
                  height: 50,
                  width: 300,
                  child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Profile()));
                      },
                      child: Text("Profile",style: TextStyle(fontSize: 25),),style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xffE87777),width: 2.5),
                      foregroundColor: Color(0xffE77381)
                  )
                  ),
                ),
              ),
            ), //Profile
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: Center(
                child: SizedBox(
                  height: 50,
                  width: 300,
                  child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Activity()));
                      },
                      child: Text("Sport Booking",style: TextStyle(fontSize: 25),),style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xffE87777),width: 2.5),
                    foregroundColor: Color(0xffE77381)
                  )
                  ),
                ),
              ),
            ), // Sport Booking
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: Center(
                child: SizedBox(
                  height: 50,
                  width: 300,
                  child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Tournament();
                        },));
                      },
                      child: Text("Tournament Booking",style: TextStyle(fontSize: 25),),style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xffE87777),width: 2.5),
                      foregroundColor: Color(0xffE77381)
                  )
                  ),
                ),
              ),
            ), //Tournament Booking
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: Center(
                child: SizedBox(
                  height: 50,
                  width: 300,
                  child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return PastBooking();
                        },));
                      },
                      child: Text("Your Booking",style: TextStyle(fontSize: 25),),style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xffE87777),width: 2.5),
                      foregroundColor: Color(0xffE77381)
                  )
                  ),
                ),
              ),
            ), //Your Booking
            Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: Center(
                child: SizedBox(
                  height: 50,
                  width: 300,
                  child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                            context, MaterialPageRoute(builder: (context) => Screen()));
                      },
                      child: Text("Log-out",style: TextStyle(fontSize: 25),),style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xffE87777),width: 2.5),
                      foregroundColor: Color(0xffE77381)
                  )
                  ),
                ),
              ),
            ), // Log-out
          ],
        ),
      ),
    );
  }
}
