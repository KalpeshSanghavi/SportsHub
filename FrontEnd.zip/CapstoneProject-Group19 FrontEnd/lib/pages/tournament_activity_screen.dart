import 'package:flutter/material.dart';
import 'package:sporthub/pages/login_screen.dart';
import 'package:sporthub/pages/menubar_screen.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/cricket_ground.dart';
import 'package:sporthub/pages/tournament_ground.dart';

class Tournament_Activity extends StatelessWidget {
  const Tournament_Activity({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ), flexibleSpace: Container(decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],)),
      ),),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              InkWell(
                child: Container(
                  margin: const EdgeInsets.only(top: 40),
                  height: 344,
                  width: 257,
                  decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xffFF355E), Color(0xffFE6C5C)],
                          begin: Alignment.topCenter,
                          end: Alignment(0.4, 0.1)),
                      borderRadius: BorderRadius.circular(33),
                      boxShadow: [
                        const BoxShadow(color: Color(0xffFF355E), blurRadius: 25),
                      ]),
                  child: Column(
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 10),
                          height: 270,
                          child: const Image(
                            // height: 950,
                              image: AssetImage("assets/img/cricket.png"))),
                      const Text(
                        "Cricket",
                        style: TextStyle(
                            fontSize: 40,
                            fontFamily: 'Sport',
                            color: Color(0xffF9E5C5),
                            fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Tournamentground() ));
                },
              ),//Cricket
              const SizedBox(height: 15),
              InkWell(
                child: Container(
                  margin: const EdgeInsets.only(top: 40),
                  height: 344,
                  width: 257,
                  decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xff38ACEC), Color(0xff33E0FE)],
                          begin: Alignment.topCenter,
                          end: Alignment(0.4, 0.6)),
                      borderRadius: BorderRadius.circular(33),
                      boxShadow: [
                        const BoxShadow(color: Color(0xff33E0FE), blurRadius: 25),
                      ]),
                  child: Column(
                    children: [
                      Container(
                          height: 285,
                          child: const Image(
                              image: AssetImage("assets/img/football.png"))),
                      const Text(
                        "FootBall",
                        style: TextStyle(
                            fontSize: 40,
                            fontFamily: 'Sport',
                            color: Color(0xff5C6457),
                            fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                onTap: () {
                },
              ), //FootBall
              const SizedBox(height: 15),
              InkWell(
                child: Container(
                  margin: const EdgeInsets.only(top: 40),
                  height: 344,
                  width: 257,
                  decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xffEAF65F), Color(0xff16D99E)],
                          begin: Alignment.topCenter,
                          end: Alignment(0.6, 0.5)),
                      borderRadius: BorderRadius.circular(33),
                      boxShadow: [
                        const BoxShadow(color: Color(0xff16D99E), blurRadius: 25),
                      ]),
                  child: Column(
                    children: [
                      Container(
                          height: 270,
                          child: const Image(
                              image: AssetImage("assets/img/badminton.png"))),
                      const Text(
                        "Badminton",
                        style: TextStyle(
                            fontSize: 40,
                            fontFamily: 'Sport',
                            color: Color(0xffFF0808),
                            fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                onTap: () {},
              ), //Badminton
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
