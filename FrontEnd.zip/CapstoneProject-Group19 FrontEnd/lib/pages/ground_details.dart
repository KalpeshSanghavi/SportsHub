import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/login_screen.dart';
import 'package:sporthub/pages/sport_date_time.dart';

class Ground_Details extends StatefulWidget {
  const Ground_Details({super.key});

  @override
  State<Ground_Details> createState() => _Ground_DetailsState();
}

class _Ground_DetailsState extends State<Ground_Details> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: (Column(
          children: [
            SizedBox(height: 30),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Row(
                  children: [
                    Container(
                      height: 169.33,
                      width: 301.59,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/img/ground1.jpeg"),
                              fit: BoxFit.fill),
                          border: Border.all(width: 3, color: Colors.black)),
                    ),
                    SizedBox(width: 20),
                    Container(
                      height: 169.33,
                      width: 301.59,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/img/ground5.jpeg"),
                              fit: BoxFit.fill),
                          border: Border.all(width: 3, color: Colors.black)),
                    ),
                    SizedBox(width: 20),
                    Container(
                      height: 169.33,
                      width: 301.59,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/img/ground4.jpeg"),
                              fit: BoxFit.fill),
                          border: Border.all(width: 3, color: Colors.black)),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            Container(
              margin: EdgeInsets.only(right: 140),
              child: Text(
                "Parsav Box Cricket",
                style: TextStyle(
                    color: Color(0xffE77381),
                    fontSize: 24,
                    fontWeight: FontWeight.w900),
              ),
            ),
            Container(
              margin: EdgeInsets.only(right: 130),
              child: Text("S.g.Highey , Ahmedabad",
                  style: TextStyle(color: Color(0xffE77381), fontSize: 20)),
            ),
            SizedBox(height: 25),
            Container(
              margin: EdgeInsets.only(right: 20),
              height: 160,
              width: 340,
              decoration: BoxDecoration(
                  border: Border.all(width: 2, color: Color(0xffE77381)),
                  borderRadius: BorderRadius.circular(21)),
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.only(right: 180),
                    child: Text(
                      "Amenities",
                      style: TextStyle(
                          color: Color(0xffE77381),
                          fontWeight: FontWeight.w600,
                          fontSize: 25),
                    ),
                  ),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.local_parking_rounded,
                        size: 30,
                        color: Color(0xffE77381),
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Parking",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            color: Color(0xffE77381)),
                      ),
                      SizedBox(width: 40),
                      Icon(
                        Icons.wc_rounded,
                        size: 30,
                        color: Color(0xffE77381),
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Washroom",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            color: Color(0xffE77381)),
                      ),
                    ],
                  ), //Parking
                  SizedBox(height: 12),
                  Row(
                    children: [
                      SizedBox(width: 8),
                      Icon(
                        Icons.coffee_outlined,
                        size: 30,
                        color: Color(0xffE77381),
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Snackbar",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            color: Color(0xffE77381)),
                      ),
                    ],
                  ), //Snackbar
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              margin: EdgeInsets.only(right: 20),
              height: 160,
              width: 340,
              decoration: BoxDecoration(
                  border: Border.all(width: 2, color: Color(0xffE77381)),
                  borderRadius: BorderRadius.circular(21)),
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Text(
                    "Timing:",
                    style: TextStyle(
                        fontSize: 16,
                        color: Color(0xffE77381),
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    "7:00 AM TO 12:AM",
                    style: TextStyle(
                        fontSize: 16,
                        color: Color(0xffE77381),
                        fontWeight: FontWeight.w400),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Location:",
                    style: TextStyle(
                        fontSize: 16,
                        color: Color(0xffE77381),
                        fontWeight: FontWeight.w600),
                  ),
                  Text(
                    "Parsav Box Cricket near Fun Blast,",
                    style: TextStyle(
                        fontSize: 16,
                        color: Color(0xffE77381),
                        fontWeight: FontWeight.w400),
                  ),
                  Text(
                    "Shindhubhan road , Ahmedabad",
                    style: TextStyle(
                        fontSize: 16,
                        color: Color(0xffE77381),
                        fontWeight: FontWeight.w400),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              height: 40,
              width: 250,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  Color(0xffE7757C),
                  Color(0xffE66C9C),
                ],
              )),
              child: Padding(
                padding: const EdgeInsets.only(left: 15, top: 6),
                child: Text(
                  "Price Per Hour : 1500/-",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Color(0xffFFFFFF)),
                ),
              ),
            ),
            SizedBox(height: 25),
        InkWell(
          child: Container(
            height: 45,
            width: 150,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomLeft,
                  colors: <Color>[
                    Color(0xffE7757C),
                    Color(0xffE66C9C),
                  ],
                ),
                borderRadius: BorderRadius.circular(10)),
            child: Container(
              margin: EdgeInsets.only(left: 20,top: 5),
              child: Text(
                "Book Slot",
                style: TextStyle(
                    fontSize: 25,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            )),
          onTap:(){
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return Screen();
            },));
          },
        ),
            SizedBox(height: 20),
          ],
        )),
      ),
    );
  }
}
