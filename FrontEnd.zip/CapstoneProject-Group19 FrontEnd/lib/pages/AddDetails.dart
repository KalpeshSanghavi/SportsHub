import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/tournament.dart';

class AddDetails extends StatefulWidget {
  const AddDetails({super.key});

  @override
  State<AddDetails> createState() => _AddDetailsState();
}

class _AddDetailsState extends State<AddDetails> {
  TextEditingController Name = new TextEditingController();
  TextEditingController Contact = new TextEditingController();
  TextEditingController Details = new TextEditingController();
  TextEditingController Role = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  Color(0xffE7757C),
                  Color(0xffE66C9C),
                ],
              )),
        ),),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 80),
            Center(
              child: Text(
                "Add Details",
                style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w600,
                    color: Color(0xffE77381)),
              ),
            ),
            SizedBox(height:20),
            Padding(
              padding: const EdgeInsets.all(18),
              child: TextField(
                controller: Name,
                style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                      BorderSide(color: Color(0xffE77381), width: 2)),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                    BorderSide(color: Color(0xffE77381), width: 2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelText: "Enter Name",
                  labelStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 20),
                  hintText: "Enter Name",
                  hintStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 15),
              ),
            ),),
            //SizedBox(height:10),
            Padding(
              padding: const EdgeInsets.all(18),
              child: TextField(
                controller: Contact,
                style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(color: Color(0xffE77381), width: 2)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xffE77381), width: 2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  labelText: "Enter Contact Number",
                  labelStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 20),
                  hintText: "Enter Contact Number",
                  hintStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 15),
              ),
            )),
           // SizedBox(height:10),
            Padding(
              padding: const EdgeInsets.all(18),
              child: TextField(
                controller: Details,
                style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                      BorderSide(color: Color(0xffE77381), width: 2)),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                    BorderSide(color: Color(0xffE77381), width: 2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelText: "Enter Sport Details",
                  labelStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 20),
                  hintText: "Enter Sport Name",
                  hintStyle:
                  TextStyle(color: Color(0xffE77381), fontSize: 15),
              ),

            )),
           // SizedBox(height:10),
            Padding(
                padding: const EdgeInsets.all(18),
                child: TextField(
                  controller: Role,
                  style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(color: Color(0xffE77381), width: 2)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xffE77381), width: 2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    labelText: "Enter Your Role",
                    labelStyle:
                    TextStyle(color: Color(0xffE77381), fontSize: 20),
                    hintText: "Enter Your Role",
                    hintStyle:
                    TextStyle(color: Color(0xffE77381), fontSize: 15),
                  ),
                )),
          //  SizedBox(height:20),
            ElevatedButton(
               onPressed: (){
                 Navigator.push(context, MaterialPageRoute(builder: (context) {
                   return Tournament();
                 },));
               },
                style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    primary: Color(0xffFF6577),
                    onPrimary: Colors.white),
                child: Text(
                  "Confirm",
                  style: TextStyle(fontSize: 25),
                )),
            SizedBox(height:20),
          ],
        ),
      ),
    );
  }
}
