// import 'dart:html';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/sport_activity_screen.dart';
import 'package:sporthub/pages/tournament.dart';

class Welcome extends StatefulWidget {
  // final int userid;
  // Welcome({required this.userid});

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  final List<String> items = [
    'Select Loaction',
    'Gandhinagar',
    'Paldi',
    'Naroda',
    'Setelite',
    'Bopal',
  ];
  String? selectedValue;
  final TextEditingController textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        leadingWidth: 0,
        //backgroundColor: Colors.pink.shade200,
        title: Center(
            child: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        )),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 80),
                child: Container(
                  height: 70,
                  width: 300,
                  decoration: BoxDecoration(

                    borderRadius: BorderRadius.circular(20),
                  ),
                  //color: Colors.white,
                  margin: EdgeInsets.only(top: 20),

                  child: DropdownButtonHideUnderline(
                    child: DropdownButton2<String>(
                      isExpanded: true,
                      hint: Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 25,
                            color: Color(0xffE7757C),
                          ),
                          SizedBox(
                            width: 20,
                          ),
                          Text(
                            'Select Location',
                            style: TextStyle(
                                fontSize: 25,
                                color: Color(0xffE7757C),
                                fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),

                      items: items
                          .map((item) => DropdownMenuItem(
                                value: item,
                                child: Text(
                                  item,
                                  style: const TextStyle(
                                      fontSize: 20, color: Color(0xffE7757C)),
                                ),
                              ))
                          .toList(),
                      value: selectedValue,
                      onChanged: (value) {
                        setState(() {
                          selectedValue = value;
                        });
                      },
                      buttonStyleData: const ButtonStyleData(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        height: 40,
                        width: 200,
                      ),
                      dropdownStyleData: const DropdownStyleData(
                        maxHeight: 200,
                      ),
                      menuItemStyleData: const MenuItemStyleData(
                        height: 40,
                      ),
                      dropdownSearchData: DropdownSearchData(
                        searchController: textEditingController,
                        searchInnerWidgetHeight: 50,
                        searchInnerWidget: Container(
                          height: 50,
                          padding: const EdgeInsets.only(
                            top: 8,
                            bottom: 4,
                            right: 8,
                            left: 8,
                          ),
                          child: TextFormField(
                            expands: true,
                            maxLines: null,
                            controller: textEditingController,
                            style: TextStyle(color: Color(0xffE7757C)),
                            decoration: InputDecoration(
                              isDense: true,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 8,
                              ),
                              hintText: 'Search Your Location...',
                              hintStyle: TextStyle(
                                  color: Color(0xffE7757C), fontSize: 20),
                            ),
                          ),
                        ),
                        searchMatchFn: (item, searchValue) {
                          return item.value.toString().contains(searchValue);
                        },
                      ),
                      //This to clear the search value when you close the menu
                      onMenuStateChange: (isOpen) {
                        if (!isOpen) {
                          textEditingController.clear();
                        }
                      },
                    ),
                  ),
                ),
              ),
              InkWell(
                child: Container(
                  margin: EdgeInsets.only(top: 40),
                  height: 204,
                  width: 334,
                  decoration: BoxDecoration(
                      // color: Colors.lightBlueAccent.shade200,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomLeft,
                        colors: <Color>[
                          Color(0xffE7757C),
                          Color(0xffE66C9C),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(44)),
                  child: Column(
                    children: [
                      Container(
                          width: 280,
                          height: 160,
                          child:
                              Image(image: AssetImage("assets/img/sport.png"))),
                      Text(
                        "Sport Activity",
                        style: TextStyle(
                            fontSize: 30,
                            fontFamily: 'Sport',
                            color: Colors.white,
                            fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Activity()));
                },
              ),
              InkWell(
                child: Container(
                    margin: EdgeInsets.only(top: 30),
                    height: 204,
                    width: 334,
                    decoration: BoxDecoration(

                        // color: Colors.lightBlueAccent.shade200,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(44)),
                    child: Column(
                      children: [
                        Container(
                            width: 280,
                            height: 160,
                            child: Image(
                                image:
                                    AssetImage("assets/img/Tournament.png"))),
                        Text(
                          "Tournament",
                          style: TextStyle(
                              fontSize: 30,
                              fontFamily: 'Sport',
                              color: Colors.white,
                              fontWeight: FontWeight.w900),
                        ),
                        //SizedBox(height: 20),
                      ],
                    )),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Tournament()));
                },
              ),
              //SizedBox(height: 20)
            ],
          ),
        ),
      ),
    );
  }
}

// For Drop Down
// Container(
//   height: 60,
//   width: double.infinity,
//   alignment: Alignment.centerLeft,
//   child: DropdownButton(
//     value: _selectedLocation,
//     onChanged: (newValue) {
//       setState(() {
//         _selectedLocation = newValue.toString();
//       });
//     },
//     items: <String>[
//       'Location 1',
//       'Location 2',
//       'Location 3',
//       // Add more locations as needed
//     ].map<DropdownMenuItem<String>>((String value) {
//       return DropdownMenuItem<String>(
//         value: value,
//         child: Text(value),
//       );
//     }).toList(),
//   ),),
