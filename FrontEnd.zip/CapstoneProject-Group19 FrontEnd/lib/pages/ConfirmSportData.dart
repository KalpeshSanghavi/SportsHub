import 'package:flutter/material.dart';
import 'package:sporthub/pages/Confirm_Slot.dart';
import 'package:sporthub/pages/Sport_Payment.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';

class ConfirmSport extends StatefulWidget {
  const ConfirmSport({super.key});

  @override
  State<ConfirmSport> createState() => _ConfirmSportState();
}

class _ConfirmSportState extends State<ConfirmSport> {
  TextEditingController Name = new TextEditingController();
  TextEditingController Contact = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 50),
              Container(
                height: 180,
                width: 336,
                decoration: BoxDecoration(
                    border: Border.all(width: 2.5, color: Color(0xffE87777)),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Date : ",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("07-10-2024",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Time: ",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("7:00 PM To 8:00 PM",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Amount : ",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("1500/-",
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 25),
              Text(
                "Enter The Details",
                style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 30,
                    color: Color(0xffE77381)),
              ),
              SizedBox(height: 25),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Container(

                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                        Color(0xffE7757C),
                        Color(0xffE66C9C),
                      ],
                    ),
                    borderRadius:
                        BorderRadius.circular(15), // Set border radius here
                  ),
                  child: TextField(
                    controller: Name,style: TextStyle(fontSize: 20,color: Colors.white),
                    decoration: InputDecoration(
                      hintText: "Enter Name",
                      hintStyle: TextStyle(fontSize: 20, color: Colors.white),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                        Color(0xffE7757C),
                        Color(0xffE66C9C),
                      ],
                    ),
                    borderRadius:
                        BorderRadius.circular(15), // Set border radius here
                  ),
                  child: TextField(
                    controller: Contact,style: TextStyle(fontSize: 20,color: Colors.white),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      hintText: "Enter Contact Number",
                      hintStyle: TextStyle(fontSize: 20, color: Colors.white),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
          InkWell(
            child: Container(
              height: 45,
              width: 130,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomLeft,
                    colors: <Color>[
                      Color(0xffE7757C),
                      Color(0xffE66C9C),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(10)),
              child: Container(
                margin: EdgeInsets.only(left: 35),
                child: Text(
                  "Next",
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              )),
            onTap:(){
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Sport_Payment();
              },));
            },
          ),
            ],
          ),
        ),
      ),
    );
  }
}
