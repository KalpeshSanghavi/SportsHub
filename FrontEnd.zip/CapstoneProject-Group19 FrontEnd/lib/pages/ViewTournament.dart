import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/AddDetails.dart';
import 'package:http/http.dart' as http;
import 'package:sporthub/pages/bottom_bar_screen.dart';

class ViewTournament extends StatefulWidget {
  const ViewTournament({super.key});

  @override
  State<ViewTournament> createState() => _ViewTournamentState();
}

class _ViewTournamentState extends State<ViewTournament> {
  String organiser='';
  String sports_type='';
  String required_player='';
  String start_date='';

  List filteredList = [];

  Future<void> getrecord() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String organiser = prefs.getString('organiser') ?? ''; // Retrieve token from shared preferences
    String sports_type = prefs.getString('sports_type') ?? '';
    String required_player = prefs.getString('required_player') ?? '';
    String start_date = prefs.getString('start_date') ?? '';

    setState(() {
      organiser=organiser;
      sports_type=sports_type;
      required_player=required_player;
      start_date=start_date;

    });
    String uri = "http://10.0.2.2//FetchCity.php";

    try{
      var response = await http.get(Uri.parse(uri));

      setState(() {
        filteredList = json.decode((response.body));
      });
    }
    catch(e){print(e);}
  }

  @override
  void initState() {
    getrecord();
    super.initState();
    }

  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 30),
              Container(
                height: 210,
                width: 336,
                decoration: BoxDecoration(
                    border: Border.all(width: 2.5, color: Color(0xffE87777)),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Organizer : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Meet",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Sport Name : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Cricket",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Required Player : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("3 Player",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 80),
                      child: Text(
                        "(2 Bowler and 1 All Rounder)",
                        style: TextStyle(
                            fontSize: 18,
                            color: Color(0xffE77381),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Date : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("07-10-23",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return AddDetails();
                          },));
                        },
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            primary: Color(0xffFF6577),
                            onPrimary: Colors.white),
                        child: Text(
                          "Select",
                          style: TextStyle(fontSize: 25),
                        ))
                  ],
                ),
              ), //1st
              SizedBox(height: 20),

              Container(
                height: 210,
                width: 336,
                decoration: BoxDecoration(
                    border: Border.all(width: 2.5, color: Color(0xffE87777)),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Organizer : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Vraj",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Sport Name : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Cricket",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Required Player : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("2 Player",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 80),
                      child: Text(
                        "(1 Bowler and 1 All Rounder)",
                        style: TextStyle(
                            fontSize: 18,
                            color: Color(0xffE77381),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Date : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("15-02-24",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return AddDetails();
                          },));

                        },
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            primary: Color(0xffFF6577),
                            onPrimary: Colors.white),
                        child: Text(
                          "Select",
                          style: TextStyle(fontSize: 25),
                        ))
                  ],
                ),
              ), //2nd
              SizedBox(height: 20),

              Container(
                height: 210,
                width: 336,
                decoration: BoxDecoration(
                    border: Border.all(width: 2.5, color: Color(0xffE87777)),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Organizer : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Yash",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Sport Name : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Cricket",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Required Player : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("4 Player",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 80),
                      child: Text(
                        "(2 Bowler and 2 Batsman)",
                        style: TextStyle(
                            fontSize: 18,
                            color: Color(0xffE77381),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Date : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("07-03-24",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return AddDetails();
                          },));
                        },
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            primary: Color(0xffFF6577),
                            onPrimary: Colors.white),
                        child: Text(
                          "Select",
                          style: TextStyle(fontSize: 25),
                        ))
                  ],
                ),
              ), //3rd
              SizedBox(height: 20),

              Container(
                height: 210,
                width: 336,
                decoration: BoxDecoration(
                    border: Border.all(width: 2.5, color: Color(0xffE87777)),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Organizer : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Pratham",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Sport Name : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("Cricket",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Required Player : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("1 Player",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 80),
                      child: Text(
                        "(1 Batsman)",
                        style: TextStyle(
                            fontSize: 18,
                            color: Color(0xffE77381),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Date : ",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffE77381)),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text("07-10-23",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Color(0xffE77381)))
                      ],
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return AddDetails();
                          },));
                        },
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            primary: Color(0xffFF6577),
                            onPrimary: Colors.white),
                        child: Text(
                          "Select",
                          style: TextStyle(fontSize: 25),
                        ))
                  ],
                ),
              ), //4th
              SizedBox(height: 20),

              // Container(
              //   height: 210,
              //   width: 336,
              //   decoration: BoxDecoration(
              //       border: Border.all(width: 2.5, color: Color(0xffE87777)),
              //       borderRadius: BorderRadius.circular(10)),
              //   child: Column(
              //     mainAxisAlignment: MainAxisAlignment.center,
              //     children: [
              //       Row(
              //         children: [
              //           Padding(
              //             padding: const EdgeInsets.only(left: 10),
              //             child: Text(
              //               "Organizer : ",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w600,
              //                   color: Color(0xffE77381)),
              //             ),
              //           ),
              //           SizedBox(width: 10),
              //           Text("Meet",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                   color: Color(0xffE77381)))
              //         ],
              //       ),
              //       Row(
              //         children: [
              //           Padding(
              //             padding: const EdgeInsets.only(left: 10),
              //             child: Text(
              //               "Sport Name : ",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w600,
              //                   color: Color(0xffE77381)),
              //             ),
              //           ),
              //           SizedBox(width: 10),
              //           Text("Cricket",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                   color: Color(0xffE77381)))
              //         ],
              //       ),
              //       Row(
              //         children: [
              //           Padding(
              //             padding: const EdgeInsets.only(left: 10),
              //             child: Text(
              //               "Required Player : ",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w600,
              //                   color: Color(0xffE77381)),
              //             ),
              //           ),
              //           SizedBox(width: 10),
              //           Text("3 Player",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                   color: Color(0xffE77381)))
              //         ],
              //       ),
              //       Padding(
              //         padding: const EdgeInsets.only(right: 80),
              //         child: Text(
              //           "(2 Bowler and 1 All Rounder)",
              //           style: TextStyle(
              //               fontSize: 18,
              //               color: Color(0xffE77381),
              //               fontWeight: FontWeight.bold),
              //         ),
              //       ),
              //       Row(
              //         children: [
              //           Padding(
              //             padding: const EdgeInsets.only(left: 10),
              //             child: Text(
              //               "Date : ",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w600,
              //                   color: Color(0xffE77381)),
              //             ),
              //           ),
              //           SizedBox(width: 10),
              //           Text("07-10-23",
              //               style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                   color: Color(0xffE77381)))
              //         ],
              //       ),
              //       SizedBox(height: 10),
              //       ElevatedButton(
              //           onPressed: () {
              //             Navigator.push(context, MaterialPageRoute(builder: (context) {
              //               return AddDetails();
              //             },));
              //           },
              //           style: ElevatedButton.styleFrom(
              //               shape: RoundedRectangleBorder(
              //                 borderRadius: BorderRadius.circular(5.0),
              //               ),
              //               primary: Color(0xffFF6577),
              //               onPrimary: Colors.white),
              //           child: Text(
              //             "Select",
              //             style: TextStyle(fontSize: 25),
              //           ))
              //     ],
              //   ),
              // ), //5th
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
