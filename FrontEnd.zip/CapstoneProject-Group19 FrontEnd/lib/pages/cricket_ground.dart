import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/ground_details.dart';

class SportGround extends StatefulWidget {
  const SportGround({super.key});

  @override
  State<SportGround> createState() => _SportGroundState();
}

class _SportGroundState extends State<SportGround> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
        appBar: AppBar(
          //leadingWidth: 0,
          titleSpacing: 87,
          title: Text(
            "Sports Hub",
            style: TextStyle(
                fontSize: 25,
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'FontHed'),
          ), flexibleSpace: Container(decoration: const BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft,
              end: Alignment.bottomLeft,
              colors: <Color>[
                Color(0xffE7757C),
                Color(0xffE66C9C),
              ],)),
        ),),
        body: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 45),
              child: Column(
                children: [
                  InkWell(
                    child: Container(
                      height: 215,
                      width: 346,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 346,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15)),
                                child: Image(
                                    image: AssetImage("assets/img/ground1.jpeg"),
                                    fit: BoxFit.fill),
                              )),
                          Text(
                            "Parsav Box Cricket",
                            style:
                                TextStyle(color: Color(0xffFFFFFF), fontSize: 24),
                          ),
                          Text("S.g.Highey , Ahmedabad",
                              style: TextStyle(
                                  color: Color(0xffFFFFFF), fontSize: 13))
                        ],
                      ),
                    ),
                    onTap: (){
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Ground_Details()));
                    },
                  ), //1st

                  SizedBox(height: 30),
                  InkWell(
                    child: Container(
                      height: 215,
                      width: 346,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 346,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15)),
                                child: Image(
                                    image: AssetImage("assets/img/ground2.jpg"),
                                    fit: BoxFit.fill),
                              )),
                          Text(
                            "1545 box cricke",
                            style:
                                TextStyle(color: Color(0xffFFFFFF), fontSize: 24),
                          ),
                          Text("Sargasan, Gandhinagar",
                              style: TextStyle(
                                  color: Color(0xffFFFFFF), fontSize: 13))
                        ],
                      ),
                    ),
                    onTap: (){ Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Ground_Details()));},
                  ), //2nd

                  SizedBox(height: 30),
                  InkWell(
                    child: Container(
                      height: 215,
                      width: 346,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 346,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15)),
                                child: Image(
                                    image: AssetImage("assets/img/ground3.jpeg"),
                                    fit: BoxFit.fill),
                              )),
                          Text(
                            "Onestop Turf",
                            style:
                                TextStyle(color: Color(0xffFFFFFF), fontSize: 24),
                          ),
                          Text("Adalaj, Gandhinagar-Gujarat",
                              style: TextStyle(
                                  color: Color(0xffFFFFFF), fontSize: 13))
                        ],
                      ),
                    ),
                    onTap: (){ Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Ground_Details()));},
                  ), //3nd

                  SizedBox(height: 30),
                  InkWell(
                    child: Container(
                      height: 215,
                      width: 346,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 346,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15)),
                                child: Image(
                                    image: AssetImage("assets/img/ground4.jpeg"),
                                    fit: BoxFit.fill),
                              )),
                          Text(
                            "Box Cricket Hillock",
                            style:
                                TextStyle(color: Color(0xffFFFFFF), fontSize: 24),
                          ),
                          Text("Vaishno Devi Circle , Ahmedabad",
                              style: TextStyle(
                                  color: Color(0xffFFFFFF), fontSize: 13))
                        ],
                      ),
                    ),
                    onTap: (){ Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Ground_Details()));},
                  ), //4nd

                  SizedBox(height: 30),
                  InkWell(
                    child: Container(
                      height: 215,
                      width: 346,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 346,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15)),
                                child: Image(
                                    image: AssetImage("assets/img/ground5.jpeg"),
                                    fit: BoxFit.fill),
                              )),
                          Text(
                            "Green Galaxy Box Arena",
                            style:
                                TextStyle(color: Color(0xffFFFFFF), fontSize: 24),
                          ),
                          Text("Science City Rode , Ahmedabad",
                              style: TextStyle(
                                  color: Color(0xffFFFFFF), fontSize: 13))
                        ],
                      ),
                    ),
                    onTap: (){ Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Ground_Details()));},
                  ), //5nd

                  SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ));
  }
}
