import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:sporthub/pages/home_screen.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  TextEditingController Fname = TextEditingController();
  TextEditingController Lname = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController Mobile = TextEditingController();
  TextEditingController Address = TextEditingController();
  TextEditingController Area = TextEditingController();
  TextEditingController Landmark = TextEditingController();
  TextEditingController Pincode = TextEditingController();
  TextEditingController City = TextEditingController();
  TextEditingController Password = TextEditingController();

  // List<dynamic> _data = [];
  //
  // @override
  // void initState() {
  //   super.initState();
  //   fetchData();
  // }
  //
  // Future<void> fetchData() async {
  //   final response = await http.get(Uri.parse('http://192.168.1.103/sporthub/profile.php'));
  //
  //   if (response.statusCode == 200) {
  //     setState(() {
  //       _data = json.decode(response.body);
  //     });
  //   } else {
  //     throw Exception('Failed to load data');
  //   }
  // }

  String fname = '';
  String lname = '';
  String email = '';
  String mobile = '';
  String address = '';
  String area = '';
  String landmark = '';
  String pincode = '';
  String city = '';
  String password = '';

  List filteredList = [];

  Future<void> getrecord() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String fname = prefs.getString('fname') ?? ''; // Retrieve token from shared preferences
    String lname = prefs.getString('lname') ?? '';
    String email = prefs.getString('email') ?? '';
    String mobile = prefs.getString('mobile') ?? '';
    String address = prefs.getString('address') ?? '';
    String area = prefs.getString('area') ?? '';
    String landmark = prefs.getString('landmark') ?? '';
    String pincode = prefs.getString('pincode') ?? '';
    String city = prefs.getString('city') ?? '';
    String password = prefs.getString('password') ?? '';

    setState(() {
      fname = fname;
      lname = lname;
      email = email;
      mobile = mobile;
      address = address;
      area = area;
      landmark = landmark;
      pincode = pincode;
      city = city;
      password = password;

    });
    String uri = "http://10.0.2.2//sporthub/UserFetch.php";

    try {
      var response = await http.get(Uri.parse(uri));

      setState(() {
        filteredList = json.decode((response.body));
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    getrecord();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Bottom(),
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      // body: SingleChildScrollView(
      //   child: Center(
      //     child: Column(
      //        children: [
            //   SizedBox(height: 40),
            //   Stack(
            //     children: [
            //       Container(
            //         height: 180,
            //         width: 180,
            //         child: CircleAvatar(
            //           radius: 100,
            //           backgroundImage: AssetImage("assets/img/profile.png"),
            //         ),
            //       ),
            //       Positioned(
            //           bottom: 4,
            //           right: 15,
            //           child: Container(
            //             height: 40,
            //             width: 40,
            //             decoration: BoxDecoration(
            //                 shape: BoxShape.circle,
            //                 border:
            //                     Border.all(width: 3, color: Color(0xffE66C9C)),
            //                 color: Color(0xffE66C9C)),
            //             child: Icon(
            //               Icons.add_a_photo,
            //               color: Colors.white,
            //             ),
            //           ))
            //     ],
            //   ),
              //SizedBox(height: 25),
              // ListView.builder(
              //     itemCount: filteredList.length,
              //     itemBuilder: (context, index) {
              //       return ListTile(
              //         title: Column(
              //           children: [
              //           Container(
              //           width: 500,
              //           height: 50,
              //           margin: EdgeInsets.only(top:10,right:20,left:20),
              //           decoration: BoxDecoration(
              //             color: Colors.grey,
              //             borderRadius: BorderRadius.circular(20.0), // Set border radius here
              //           ),
              //           padding: EdgeInsets.only(top:10,left:20,bottom: 10),
              //           child:Text('${filteredList[index]['fname']}',style: TextStyle(fontSize: 20,color: Colors.black),),),
              //             // Padding(
              //             //   padding: const EdgeInsets.all(10),
              //             //   child: TextField(
              //             //     controller: Fname ..text = "Shreyansh",
              //             //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //             //     decoration: InputDecoration(
              //             //       labelText: "First Name",
              //             //       labelStyle:
              //             //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //             //       // prefix:(Icon(Icons.account_circle,
              //             //       //   size: 40, color: Color(0xffE77381))),
              //             //       suffixIcon: Padding(
              //             //         padding: const EdgeInsets.only(top:10),
              //             //         child: Text("Edit",
              //             //             style: TextStyle(
              //             //                 fontSize: 20,
              //             //                 color: Color(0xffE77381),
              //             //                 decoration: TextDecoration.underline,
              //             //                 decorationColor: Color(0xffE77381))),
              //             //       ),
              //             //       enabledBorder: OutlineInputBorder(
              //             //           borderRadius: BorderRadius.circular(10),
              //             //           borderSide:
              //             //           BorderSide(color: Color(0xffE77381), width: 2)),
              //             //       focusedBorder: OutlineInputBorder(
              //             //         borderSide:
              //             //         BorderSide(color: Color(0xffE77381), width: 2),
              //             //         borderRadius: BorderRadius.circular(10),
              //             //       ),
              //             //     ),
              //             //   ),
              //       ) ),
              //           ],
              //         ),
              //       );
              //     }), //ListList
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Fname ..text = "Shreyansh",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "First Name",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Lname..text = "Shah",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Last Name",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Email..text = "s@gmail.com",
              //     keyboardType: TextInputType.emailAddress,
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Email-Id",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Mobile..text = "8795462012",
              //     keyboardType: TextInputType.number,
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Contact Number",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Address..text = "Amrapali Flat",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Address",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Area..text = "Sec-22",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Area",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Landmark..text = "Bus Stand",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Landmark",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Pincode..text = "382021",
              //     keyboardType: TextInputType.number,
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Pincode",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: City..text = "Gandhinagar",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "City",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
              //
              // SizedBox(height: 5),
              // Padding(
              //   padding: const EdgeInsets.all(10),
              //   child: TextField(
              //     controller: Password..text = "12345",
              //     style: TextStyle(fontSize: 20, color: Color(0xffE77381)),
              //     decoration: InputDecoration(
              //       labelText: "Password",
              //       labelStyle:
              //       TextStyle(color: Color(0xffE77381), fontSize: 20),
              //       // prefix:(Icon(Icons.account_circle,
              //       //   size: 40, color: Color(0xffE77381))),
              //       suffixIcon: Padding(
              //         padding: const EdgeInsets.only(top:10),
              //         child: Text("Edit",
              //             style: TextStyle(
              //                 fontSize: 20,
              //                 color: Color(0xffE77381),
              //                 decoration: TextDecoration.underline,
              //                 decorationColor: Color(0xffE77381))),
              //       ),
              //       enabledBorder: OutlineInputBorder(
              //           borderRadius: BorderRadius.circular(10),
              //           borderSide:
              //           BorderSide(color: Color(0xffE77381), width: 2)),
              //       focusedBorder: OutlineInputBorder(
              //         borderSide:
              //         BorderSide(color: Color(0xffE77381), width: 2),
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //     ),
              //   ),
              // ),
      //         SizedBox(height: 20),
      //         InkWell(
      //           child: Container(
      //               height: 45,
      //               width: 130,
      //               decoration: BoxDecoration(
      //                   gradient: LinearGradient(
      //                     begin: Alignment.topLeft,
      //                     end: Alignment.bottomLeft,
      //                     colors: <Color>[
      //                       Color(0xffE7757C),
      //                       Color(0xffE66C9C),
      //                     ],
      //                   ),
      //                   borderRadius: BorderRadius.circular(10)),
      //               child: Container(
      //                 margin: EdgeInsets.only(left: 35, top: 5),
      //                 child: Text(
      //                   "Save",
      //                   style: TextStyle(
      //                       fontSize: 25,
      //                       color: Colors.white,
      //                       fontWeight: FontWeight.bold),
      //                 ),
      //               )),
      //           onTap: () {
      //             Navigator.push(context, MaterialPageRoute(
      //               builder: (context) {
      //                 return Welcome();
      //               },
      //             ));
      //           },
      //         ),
      //         SizedBox(height: 20),
      //       ],
      //     ),
      //   ),
      // ),
      body: ListView.builder(
          itemCount: filteredList.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Column(

                children: [

              Container(

                      height: 180,
                      width: 180,
                      child: CircleAvatar(
                        radius: 100,
                        backgroundImage: AssetImage("assets/img/profile.png"),
                      ),
                    ),
                    Positioned(
                        top: 4,
                        right: 15,
                        child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border:
                                  Border.all(width: 3, color: Color(0xffE66C9C)),
                              color: Color(0xffE66C9C)),
                          child: Icon(
                            Icons.add_a_photo,
                            color: Colors.white,
                          ),
                        )),
                  Container(
                      padding: EdgeInsets.only(top:50.0,right:230),
                      child:Text("First Name",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['fname']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                ],
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Last Name",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['lname']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Email",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['email']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Contact",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['mobile']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Address",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['address']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Area",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['area']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Land Mark",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['landmark']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Pincode",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['pincode']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("City",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['city']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  Container(
                      padding: EdgeInsets.only(top:20.0,left:20),
                      child:Text("Password",style:TextStyle(fontSize: 20,fontWeight: FontWeight.w600,color: Color(0xffE7757C)))
                  ),
                  Container(
                    width: 500,
                    height: 50,
                    margin: EdgeInsets.only(top:10,right:20,left:20),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomLeft,
                            colors: <Color>[
                              Color(0xffE7757C),
                              Color(0xffE66C9C),
                            ]),
                        borderRadius: BorderRadius.circular(7)),
                    padding: EdgeInsets.only(top:10,left:20,bottom: 10),
                    child:Text('${filteredList[index]['password']}',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),),),
                  // Container(
                  //     width:200,
                  //     height: 50,
                  //     color: Colors.purpleAccent,
                  //     margin: EdgeInsets.only(top:20.0,bottom: 20,left: 80),
                  //     padding: EdgeInsets.only(top:10,left:70),
                  //     child:Text("Save",style:TextStyle(fontSize: 22,fontWeight: FontWeight.bold,color: Colors.white))
                  //),
                ],
              ),
            );
            },
          ),
    );
  }
}
