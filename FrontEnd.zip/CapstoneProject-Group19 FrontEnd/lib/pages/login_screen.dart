import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/home_screen.dart';
import 'package:sporthub/pages/sign_up_screen.dart';
import 'package:sporthub/pages/sport_date_time.dart';
import 'package:http/http.dart' as http;


class Screen extends StatefulWidget {
  Screen({Key? key}) : super(key: key);

  @override
  State<Screen> createState() => _ScreenState();
}

class _ScreenState extends State<Screen> {
  //final _formKey = GlobalKey<FormState>();
  TextEditingController Name = new TextEditingController();
  TextEditingController Password = new TextEditingController();

  // Future<void> _login(BuildContext context) async {
  //   final String email = Name.text;
  //   final String password = Password.text;
  //
  //   try {
  //     final response = await http.post(
  //       Uri.parse('http://192.168.1.104/sporthub/login.php'),
  //       body: {'email': email, 'password': password},
  //     );
  //
  //     // print('Response Status Code: ${response.statusCode}');
  //     // print('Response Body: ${response.body}');
  //
  //
  //     if (response.statusCode == 200) {
  //       final responseData = json.decode(response.body);
  //       if (responseData != null && responseData['status'] == 'success') {
  //         final bool isApproved = responseData['message'] == 'Login successful';
  //         if (isApproved) {
  //           final int userid = int.parse(responseData['userid']);
  //
  //           Navigator.pushReplacement(
  //             context,
  //             MaterialPageRoute(builder: (context) => Welcome(userid: userid,)),
  //           );
  //         } else {
  //           showDialog(
  //             context: context,
  //             builder: (context) => AlertDialog(
  //               title: Text('Login Failed'),
  //               content: Text(responseData['message']),
  //               actions: <Widget>[
  //                 TextButton(
  //                   onPressed: () => Navigator.pop(context),
  //                   child: Text('OK'),
  //                 ),
  //               ],
  //             ),
  //           );
  //         }
  //       } else {
  //         showDialog(
  //           context: context,
  //           builder: (context) => AlertDialog(
  //             title: Text('Login Failed'),
  //             content: Text(responseData['message']),
  //             actions: <Widget>[
  //               TextButton(
  //                 onPressed: () => Navigator.pop(context),
  //                 child: Text('OK'),
  //               ),
  //             ],
  //           ),
  //         );
  //       }
  //     } else {
  //       showDialog(
  //         context: context,
  //         builder: (context) => AlertDialog(
  //           title: Text('Connection Error'),
  //           content: Text('Failed to connect to server.'),
  //           actions: <Widget>[
  //             TextButton(
  //               onPressed: () => Navigator.pop(context),
  //               child: Text('OK'),
  //             ),
  //           ],
  //         ),
  //       );
  //     }
  //   } catch (error) {
  //     showDialog(
  //         context: context,
  //         builder: (context) => AlertDialog(
  //           title: Text('Error'),
  //           content: Text(error.toString()),
  //           actions: <Widget>[
  //             TextButton(
  //               onPressed: () => Navigator.pop(context),
  //               child: Text('OK'),
  //             ),
  //           ],
  //         ),
  //     );
  //   }
  //   }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 87,
        title: Text(
          "Sports Hub",
          style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'FontHed'),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: <Color>[
              Color(0xffE7757C),
              Color(0xffE66C9C),
            ],
          )),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Form(
              //key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    "assets/img/login.png",
                    height: 200,
                    width: 200,
                  ),
                  Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.pink.shade300,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 20),
                  TextFormField(
                    controller: Name,
                    style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                    // validator: (value) {
                    //   if (value == null || value.isEmpty) {
                    //     return 'Please enter your name';
                    //   }
                    //   return null;
                    // },
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(color: Color(0xffE77381), width: 2)),
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                        BorderSide(color: Color(0xffE77381), width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      labelText: "Enter Name",
                      labelStyle:
                          TextStyle(color: Color(0xffE77381), fontSize: 20),
                      hintText: "Enter the name",
                      hintStyle:
                          TextStyle(color: Color(0xffE77381), fontSize: 15),
                      suffixIcon: Icon(
                        Icons.account_circle_rounded,
                        color: Color(0xffE77381),
                        size: 35,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  TextFormField(
                    controller: Password,
                    style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                    // validator: (value) {
                    //   if (value == null || value.isEmpty) {
                    //     return 'Please enter your password';
                    //   }
                    //   return null;
                    // },
                    obscureText: true,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(color: Color(0xffE77381), width: 2)),
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                        BorderSide(color: Color(0xffE77381), width: 2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      labelText: "Enter Password",
                      labelStyle:
                          TextStyle(color: Color(0xffE77381), fontSize: 20),
                      hintText: "Enter the Password",
                      hintStyle:
                          TextStyle(color: Color(0xffE77381), fontSize: 15),
                      suffixIcon: Icon(
                        Icons.remove_red_eye,
                        color: Color(0xffE77381),
                        size: 30,
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {},
                        child: Text(
                          "Forgot Password",
                          style: TextStyle(
                            color: Color.fromRGBO(231, 115, 129, 1),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      //login();
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Date_Time()));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.pink.shade200,
                      foregroundColor: Colors.white,
                      padding:
                          EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    ),
                    child: Text(
                      "Log In",
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  SizedBox(height: 10),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignUpScreen()),
                      );
                    },
                    child: Text(
                      "Don't Have An Account? Sign Up",
                      style: TextStyle(
                        fontSize: 16,
                        color: Color.fromRGBO(231, 115, 129, 1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

}
