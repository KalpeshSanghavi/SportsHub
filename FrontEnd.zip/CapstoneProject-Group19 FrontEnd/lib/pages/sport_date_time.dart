import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:sporthub/pages/ConfirmSportData.dart';
import 'package:sporthub/pages/bottom_bar_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class Date_Time extends StatefulWidget {
  const Date_Time({super.key});

  @override
  State<Date_Time> createState() => _Date_TimeState();
}

class _Date_TimeState extends State<Date_Time> {
  TextEditingController Date = new TextEditingController();

  // final _formKey = GlobalKey<FormState>();
  Future<void> insertdata() async {
    if (Date.text != "") {
      try {
        final url = Uri.parse('http://192.168.50.182/sporthub/registation.php');
        final response = await http.post(
          url,
          body: {
            'date': Date.text,
          },
        );
        //var response = json.decode((response.body));
        if (response.statusCode == 200)
        //{
        //if (response["success"] == "true")
        {
          print('Data sent successfully');
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
            //  title: Text('Sign up Successful'),
              content: Text('Data Successful'),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('OK'),
                ),
              ],
            ),
          );
        } else {
          print("Some issue");
        }
        //}
      } catch (e) {
        print('Error making HTTP request:$e');
      }
    } else {
      print("Please Fill All Fields");
    }
  }

  Future<void> _selectDate() async {
    DateTime? _picked = await showDatePicker(
        context: context,
        firstDate: DateTime.now(),
        lastDate: DateTime(2050),
        initialDate: DateTime.now());
    if (_picked != null) {
      setState(() {
        Date.text = _picked.toString().split(" ")[0];
      });
    }
  }

  String slottime = '';

  List filteredList = [];

  Future<void> getrecord() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String slottime = prefs.getString('slottime') ??
        ''; // Retrieve token from shared preferences

    setState(() {
      slottime = slottime;
    });
    String uri = "http://10.0.2.2//sporthub/Datadb.php";

    try {
      //final url = Uri.parse('http://192.168.127.182/sporthub/SlotFetch.php');
      var response = await http.get(Uri.parse(uri));

      setState(() {
        filteredList = json.decode((response.body));
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    getrecord();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: Bottom(),
        appBar: AppBar(
          titleSpacing: 87,
          title: Text(
            "Sports Hub",
            style: TextStyle(
                fontSize: 25,
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'FontHed'),
          ),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomLeft,
              colors: <Color>[
                Color(0xffE7757C),
                Color(0xffE66C9C),
              ],
            )),
          ),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                SizedBox(height: 40),
                Container(
                  height: 55,
                  width: 300,
                  margin: const EdgeInsets.only(top: 20, right: 30, left: 30),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomLeft,
                        colors: <Color>[
                          Color(0xffE7757C),
                          Color(0xffE66C9C),
                        ],
                      ),
                      borderRadius:
                          BorderRadius.circular(15), // Set border radius here
                    ),
                    child: TextField(
                      decoration: InputDecoration(
                          //filled: true,
                          //fillColor: LinearGradient(),
                          suffixIcon: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: Icon(
                              Icons.calendar_month_outlined,
                              color: Colors.white,
                              size: 40,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            //borderRadius: BorderRadius.circular(5),
                          ),
                          hintText: 'Select Date',
                          hintStyle: TextStyle(
                            fontSize: 25,
                            color: Colors.white,
                          )),
                      readOnly: true,
                      onTap: () {
                        _selectDate();
                      },
                      controller: Date,
                      style: TextStyle(
                          fontSize: 25,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(height: 60),
                // ListView.builder(
                //     itemCount: filteredList.length,
                //     itemBuilder: (context, index) {
                //       return ListTile(
                //         title: Row(
                //           children: [
                //             Padding(
                //               padding: const EdgeInsets.only(left: 10),
                //               child: Container(
                //                 height: 35,
                //                 width: 180,
                //                 decoration: BoxDecoration(
                //                     gradient: LinearGradient(
                //                       begin: Alignment.topLeft,
                //                       end: Alignment.bottomLeft,
                //                       colors: <Color>[
                //                         Color(0xffE7757C),
                //                         Color(0xffE66C9C),
                //                       ],
                //                     )),
                //                 child: Center(
                //                   child: Text(
                //                     '${filteredList[index]['slottime']}',
                //                     style: TextStyle(
                //                         fontSize: 16.5,
                //                         fontWeight: FontWeight.w900,
                //                         color: Colors.white),
                //                   ),
                //                 ),
                //               ),
                //             ),
                //             Padding(
                //               padding: const EdgeInsets.only(left: 10),
                //               child: Container(
                //                 height: 35,
                //                 width: 180,
                //                 decoration: BoxDecoration(
                //                     gradient: LinearGradient(
                //                       begin: Alignment.topLeft,
                //                       end: Alignment.bottomLeft,
                //                       colors: <Color>[
                //                         Color(0xffE7757C),
                //                         Color(0xffE66C9C),
                //                       ],
                //                     )),
                //                 child: Center(
                //                   child: Text(
                //                     "8:30 PM To 9:30 PM",
                //                     style: TextStyle(
                //                         fontSize: 16.5,
                //                         fontWeight: FontWeight.w900,
                //                         color: Colors.white),
                //                   ),
                //                 ),
                //               ),
                //             )
                //           ],
                //         ),
                //       );
                //     }),
                SizedBox(height: 0),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "7:00 AM To 8:00 AM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "8:30 AM To 9:30 AM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //1st Row

                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "10:00 AM To 11:00 AM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "11:30 AM To 12:30 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //2nd Row

                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "1:00 PM To 2:00 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "2:30 PM To 3:30 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //3rd Row

                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "4:00 PM To 5:00 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "5:30 PM To 6:30 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //4th Row

                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "7:00 PM To 8:00 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "8:30 PM To 9:30 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //5th Row

                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "10:00 PM To 11:00 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        height: 35,
                        width: 180,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            Color(0xffE7757C),
                            Color(0xffE66C9C),
                          ],
                        )),
                        child: Center(
                          child: Text(
                            "11:30 PM To 12:30 PM",
                            style: TextStyle(
                                fontSize: 16.5,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                ), //6th Row
                SizedBox(height: 50),
                Container(
                  height: 45,
                  width: 130,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomLeft,
                        colors: <Color>[
                          Color(0xffE7757C),
                          Color(0xffE66C9C),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(10)),
                  child: InkWell(
                    child: Container(
                      margin: EdgeInsets.only(left: 35),
                      child: Text(
                        "Next",
                        style: TextStyle(
                            fontSize: 30,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    onTap: () {
                      insertdata();
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return ConfirmSport();
                        },
                      ));
                    },
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
