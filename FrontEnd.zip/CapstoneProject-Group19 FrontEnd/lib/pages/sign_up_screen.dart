import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:sporthub/pages/login_screen.dart';
import 'package:http/http.dart' as http;
import 'package:sporthub/pages/sport_date_time.dart';

class SignUpScreen extends StatefulWidget {
  SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  TextEditingController Fname = TextEditingController();
  TextEditingController Lname = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController Mobile = TextEditingController();
  TextEditingController Address = TextEditingController();
  TextEditingController Area = TextEditingController();
  TextEditingController Landmark = TextEditingController();
  TextEditingController Pincode = TextEditingController();
  TextEditingController City = TextEditingController();
  TextEditingController Password = TextEditingController();

  // final _formKey = GlobalKey<FormState>();
  Future<void> insertdata() async {
    if (Fname.text != "" ||
        Lname.text != "" ||
        Email.text != "" ||
        Mobile.text != "" ||
        Address.text != "" ||
        Area.text != "" ||
        Landmark.text != "" ||
        Pincode.text != "" ||
        City.text != "" ||
        Password.text != "") {
      try {
        final url = Uri.parse('http://192.168.50.182/sporthub/registation.php');
        final response = await http.post(
          url,
          body: {
            'fname': Fname.text,
            'lname': Lname.text,
            'email': Email.text,
            'mobile': Mobile.text,
            'address': Address.text,
            'area': Area.text,
            'landmark': Landmark.text,
            'pincode': Pincode.text,
            'city': City.text,
            'password': Password.text,
          },
        );
        //var response = json.decode((response.body));
        if (response.statusCode == 200)
        //{
        //if (response["success"] == "true")
        {
          print('Data sent successfully');
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Sign up Successful'),
              content: Text('Data Successful'),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('OK'),
                ),
              ],
            ),
          );

        } else {
          print("Some issue");
        }
        //}
      } catch (e) {
        print('Error making HTTP request:$e');
      }
    } else {
      print("Please Fill All Fields");
    }
  }

  // DBConnection

  @override
  Widget build(BuildContext context) {
    return (Scaffold(
        appBar: AppBar(
          titleSpacing: 87,
          title: Text(
            "Sports Hub",
            style: TextStyle(
                fontSize: 25,
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'FontHed'),
          ),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomLeft,
              colors: <Color>[
                Color(0xffE7757C),
                Color(0xffE66C9C),
              ],
            )),
          ),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Column(
                children: [
                  Image.asset(
                    "assets/img/login.png",
                    height: 200,
                    width: 200,
                  ),
                  Text(
                    "Sign Up",
                    style: TextStyle(
                      fontSize: 45,
                      color: Colors.pink.shade300,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  // Login Text

                  Padding(
                    padding:
                        const EdgeInsets.only(left: 20, right: 20, top: 25),
                    child: TextFormField(
                      controller: Fname,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),

                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "First Name",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter First name",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  // First Name Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Lname,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Last Name",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter Last name",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  // Last Name Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Email,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Email Address",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter Email Address",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  // Email Address Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Mobile,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Contact Number",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter Contact Number",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  // Contact Number
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Address,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Address",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter Address",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  //Address Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Area,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Area",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter Area",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  //Area Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Landmark,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Landmark",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Landmark",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  //LandMark Box

                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Pincode,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter Near Location';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Pincode",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Pincode",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  //PinCode

                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(
                      left: 20,
                      right: 20,
                    ),
                    child: TextFormField(
                      controller: City,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "City",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter City name",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                      ),
                    ),
                  ),
                  //City Box
                  SizedBox(
                    height: 13,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextFormField(
                      controller: Password,
                      style: TextStyle(color: Color(0xffE77381), fontSize: 17),
                      obscureText: true,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(color: Color(0xffE77381), width: 2)),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Color(0xffE77381), width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Enter Password",
                        labelStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 20),
                        hintText: "Enter the Password",
                        hintStyle:
                            TextStyle(color: Color(0xffE77381), fontSize: 15),
                        suffixIcon: Icon(
                          Icons.remove_red_eye,
                          color: Color(0xffE77381),
                          size: 30,
                        ),
                      ),
                    ),
                  ),
                  // Password Box
                  SizedBox(
                    height: 23,
                  ),
                  // 2 Box between Break

                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10, top: 5),
                    child: ElevatedButton(
                        onPressed: () {
                          //if (_formKey.currentState!.validate()) {}
                          insertdata();
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return Screen();
                          },));
                        },
                        style: ElevatedButton.styleFrom(
                            primary: Colors.pink.shade200,
                            onPrimary: Colors.white),
                        child: Text(
                          "Sign-Up",
                          style: TextStyle(fontSize: 20),
                        )),
                  ),
                  // 2 Box between Break
                  // Login Button
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Screen()));
                        },
                        child: Text(
                          "Already have an account?? Sign in",
                          style: TextStyle(
                            fontSize: 20,
                            color: Color.fromRGBO(231, 115, 129, 100),
                          ),
                        )),
                  ),
                ],
              ),
            ),
          ),
        )));
  }
}
