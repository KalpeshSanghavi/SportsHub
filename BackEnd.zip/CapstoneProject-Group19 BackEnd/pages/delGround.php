<?php

session_start();

// Check if user is logged in
if (!isset($_SESSION['userData'])) {
    // Redirect to login page
    header('Location: sign-in.php');
    exit;
}

// Include database connection and configuration file
include_once 'config.php';

// Fetch user data from session
$userData = $_SESSION['userData'];

// Check if user is super admin
$isSuperAdmin = ($userData['Username'] === 'superadmin');

$delete=$_GET['id'];
$query="delete from ground where groundid='$delete'";
if(mysqli_query($conn,$query))
{
  echo "<script>window.open('ground.php?deleted=Record has been deleted','_self')</script>";
}

?>
