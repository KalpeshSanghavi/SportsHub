<?php

session_start();

// Include database connection and configuration file
include_once 'config.php';

// Get username and password from login form
$username = $_POST['username'];
$password = $_POST['password'];

// Query to check user credentials
$query = "SELECT * FROM adminprofile WHERE Username = '$username' AND Password = '$password'";
$result = mysqli_query($conn, $query);

// Check if query returns any result
if (mysqli_num_rows($result) == 1) 
{
    // Fetch user data
    $userData = mysqli_fetch_assoc($result);

    // Store user data in session
    $_SESSION['userData'] = $userData;

    // Redirect to dashboard
    header('Location: dashboard.php');
}
else
{
    // Redirect back to login page with error message
    header('Location: sign-in.php?error=1');
}

?>